# Stock Research

No original code has been made as of 4/12/19. I have instead been researching on how to web scrape and use API's.

## Things Needed

In my attempts to web scrape on this machine I have run into a few issues. The main issue is that I cannot install third party C++ libraries onto the machine as I lack administrator access. I can do the work on my home machine. These are my findings:

### libcurl

**_libcurl_** is a C++ library that is able to fetch data from URLs and make them manipulatable. The example projects that I have found and are posted both use this library.

## Plan

The plan as of 4/12/19 is to go to my home machine and install all the necessary libraries and experiment on my own machine. I will then bring my computer to school so that I am able to work. I will most likely use one of the example programs as a class to fetch data and then I will format it in a way that is beneficial to my group.
