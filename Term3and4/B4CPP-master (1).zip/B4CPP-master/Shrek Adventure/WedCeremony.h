#ifndef WEDCEREMONY_H_
#define WEDCEREMONY_H_
#include <ctime>

 class WedCeremony {
 public:
	 WedCeremony();
	 bool run();
 private:
 };



#endif /* WEDCEREMONY_H_ */
