#ifndef CASTLE1_H_
#define CASTLE1_H_
#include <string>

class Castle1 {
public:
	Castle1();
	bool my_new_function();
private:
};

#endif /* CASTLE1_H_ */
