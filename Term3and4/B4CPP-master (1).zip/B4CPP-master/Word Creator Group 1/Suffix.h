// Made by Jacob Schwartz

#ifndef SUFFIX_H_
#define SUFFIX_H_

#include "Suffix.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>


class Suffix {
public:
	Suffix();
	int randomSuffix();
	std::string suffixSelect();
	std::string func();
	std::string defSelect();
};

#endif /* SUFFIX_H_ */
