#ifndef WORDH_H_
#define WORDH_H_
#include <string>
#include <time.h>

class RootWord {
public:
	RootWord();
	std::string Roots();
	std::string Definition();
	int randRoot();
private:

};



#endif /* WORDH_H_ */
