//Created on March 8, 2019
// Created by Mason Rasmussen

#ifndef WORDH_H_
#define WORDH_H_
#include <string>
#include <time.h>

class Prefix {
public:
	Prefix();
	std::string Prefix();
	std::string Definition();
	int randPrefix();
private:
};