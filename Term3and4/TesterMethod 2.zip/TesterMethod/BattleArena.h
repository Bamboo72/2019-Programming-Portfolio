/*
 * BattleArena.h
 *
 *  Created on: Feb 28, 2019
 *      Author: 9643873
 */

#ifndef BATTLEARENA_H_
#define BATTLEARENA_H_

#include <iostream>
#include <string>
#include <cstdlib>
#include "BattleArena.h"

using namespace std;

class Battle {

	//variables
	public:
	int knights;
	int health;
	int problems;

	//constructor
	knights = rand() % 101;


	//method calcs
void fight(){


}

};



#endif /* BATTLEARENA_H_ */
