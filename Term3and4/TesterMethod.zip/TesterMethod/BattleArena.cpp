/*
 * BattleArena.cpp for the Shrek Adventure
 *
 *  Created on: Feb 28, 2019
 *      Author: Jacob Schwartz
 */

/*
 * Initial speech
 * Ale attack
 * Donkey's barrel attack
 * Wrestling attack - chair, donkey,
 * Ending and forced quest
 * */

#include <iostream>

#include "BattleArena.h"

using namespace std;

int main(){}
