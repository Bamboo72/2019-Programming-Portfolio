


#include <iostream>
#include <string>
#include <cstdlib>
#include "BattleArena.h"

using namespace std;

int main(){
	BattleArena B1;
	B1.fight();
	return 0;

}
