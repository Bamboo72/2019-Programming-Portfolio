/*
 * BattleArena.h
 *
 *  Created on: Feb 28, 2019
 *      Author: 9643873
 */

#ifndef BATTLEARENA_H_
#define BATTLEARENA_H_

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

class BattleArena {

public:
	BattleArena();
	void fight();

private:
};

#endif /* BATTLEARENA_H_ */
