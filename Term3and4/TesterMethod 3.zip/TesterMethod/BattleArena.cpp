/*
 * BattleArena.cpp for the Shrek Adventure
 *
 *  Created on: Feb 28, 2019
 *      Author: Jacob Schwartz
 */

/*
 * Initial speech
 * Ale attack
 * Donkey's barrel attack
 * Wrestling attack - chair, donkey,
 * Ending and forced quest
 * */

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "BattleArena.h"

using namespace std;

BattleArena::BattleArena() {
	//Hia stackoverflow
}

void BattleArena::fight() {
	srand((int) time(0));

	string answer;
	int trueAnswer;
	int knights = rand() % 100 + 50;
	int height = rand() % 10 + 5;
	int radius = rand() % 5 + 2;

	cout
			<< "Shrek enters into the noisy battle arena, determined to get his swamp back."
			<< endl;
	cout
			<< "Unexpectedly, Lord Farquaad makes Shrek the target of the tournament."
			<< endl;
	cout << "Help Shrek to fight all the knights!" << endl;
	cout << "There are " << knights
			<< " knights. Shrek has a few ways to take them out:" << endl;
	cout << "Shrek smacks a nearby ale barrel causing it to gush out." << endl;
	cout
			<< "Shrek smacks the ale barrel causing it to gush out. \n If the barrel was entirely full, the height was "
			<< height << " feet, and the radius was " << radius
			<< " feet, how much ale in cubic feet was spewed out?" << endl;
	cout << "hint: volume of a cylinder == 3.14 r^2 h" << endl;

	trueAnswer = 3.14 * (radius * radius) * height;
	if (answer == to_string(trueAnswer)) {
		knights -= rand() % knights;
		cout << "The attack was successful, so there are " << knights << " knights left, but Shrek's fist's quickly took care of them." << endl;
	}

}
